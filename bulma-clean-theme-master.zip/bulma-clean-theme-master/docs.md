---
layout: page
title: Docs
menubar: docs_menu
show_sidebar: false
---

Bulma Clean Theme has many features available. The documentation has been spit into categories to make it easier to navigate through the various features. 

Find out how to install Bulma Clean Theme in your Jekyll project in the [Installation](/bulma-clean-theme/docs/getting-started/installation/) section.