---
layout: page
title: Image Gallery
subtitle: An example image gallery page
description: A simple image gallery page 
gallery: example_gallery
show_sidebar: false
---

This is an example page with an image gallery. 

[View the Image Gallery Docs](/bulma-clean-theme/docs/image-gallery/)